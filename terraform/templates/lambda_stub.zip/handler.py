"""Placeholder Terraform deploys before curbside-backend's deploy workflow ships real code."""


def handler(event, context):
    return {
        "statusCode": 503,
        "headers": {"Content-Type": "application/json"},
        "body": '{"data":null,"error":{"code":"not_deployed","message":"Stub: run the curbside-backend deploy"},"meta":{}}',
    }
